function innerProduct = computeCurveInnerProduct(curve1, curve2)
% computeCurveInnerProduct: Computes the inner product between two 2xT curves
%
% Inputs:
% - curve1: 2xT matrix representing the first curve
% - curve2: 2xT matrix representing the second curve
%
% Output:
% - innerProduct: Inner product of the two curves

% Checking dimensions of the curves
    if size(curve1, 1) ~= 2 || size(curve2, 1) ~= 2
        error('Ambas curvas deben tener dimensiones 2xT.');
    end

    numPoints = size(curve1, 2);

    pointwiseProductSum = sum(curve1 .* curve2);

% Approximation of the integral using the rectangle rule
    delta = 1 / (numPoints - 1);  
    innerProduct = sum(pointwiseProductSum) * delta;
end
