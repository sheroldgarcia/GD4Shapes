function new_curve = adjustCurve(aligned_curve2, transfValues)
   
    % adjustCurve: Computes the inverse function of the transformed values
    %
    numPoints = length(transfValues);
    normalizedPositions = linspace(1/numPoints, 1, numPoints); 
    inverseMapping = interp1(transfValues, normalizedPositions, normalizedPositions, 'linear');

    transf_inversa = (inverseMapping-inverseMapping(1))/(inverseMapping(end)-inverseMapping(1)); 

    %mapping of the curve according to the obtained fitting transform
    [n,T] = size(aligned_curve2);
    
    for j=1:n
        new_curve(j,:) = spline(linspace(0,1,T) , aligned_curve2(j,:) , transf_inversa);
    end

end