%test script for functions 


%CURVE1
load('samples/cel_sick1.mat'); %


%CURVE2
load('samples/cel_sick2.mat');


c1 = CurveUniformDistribution(c1,295);  
c2 = CurveUniformDistribution(c2,295);
plotTwoCurves(c1,c2,'Original Shapes');


%%Centering curves
c1 = centerCurve(c1);
c2 = centerCurve(c2);
plotTwoCurves(c1,c2,'Centered Shapes');

%Aligning curves
[aligned_curve1, aligned_curve2, curve1_rotation_matrix, curve2_rotation_matrix] = AlignCurvesToXAxis(c1,c2); 
plotTwoCurves(aligned_curve1,aligned_curve2,'AlignCurvesToXAxis, Fix Parametrization');


% Show the applied and optimal rotation matrix
disp('Calculated Optimal Rotation Matrix 1:');
disp(curve1_rotation_matrix);
disp('Calculated Optimal Rotation Matrix 2:');
disp(curve2_rotation_matrix);

% % shape space projection
q_represent_c1 = curveToUnitCurve(aligned_curve1);  
q_represent_c2 = curveToUnitCurve(aligned_curve2);
q1 = ProjectCurveToNormalSpace(q_represent_c1); 
q2 = ProjectCurveToNormalSpace(q_represent_c2);

% % elastic transform
transf = alignment(q1,q2); 

% % Adjusting second curve
aligned_curve2_new = adjustCurve(aligned_curve2, transf);
q_represent_c2_adjust = curveToUnitCurve(aligned_curve2_new);

% %Computing distance
d = acos(computeCurveInnerProduct(q_represent_c1,q_represent_c2_adjust))

% % Obtaining geodesic
Geod = computeGeodesicPath(q_represent_c1,q_represent_c2_adjust,6);
plot2DGeod(Geod); 


