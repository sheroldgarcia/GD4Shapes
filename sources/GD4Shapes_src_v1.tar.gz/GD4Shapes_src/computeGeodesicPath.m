function geodesicPath = computeGeodesicPath(curveStart, curveEnd, numSteps)
% computeGeodesicPath: Computes a geodesic in the SRVF curve space between curveStart and curveEnd
%
% Inputs:
% - curveStart: 2xT matrix representing the start curve in SRVF space
% - curveEnd: 2xT matrix representing the end curve in SRVF space
% - numSteps: Number of interpolation steps in the geodesic
%
% Output:
% - geodesicPath: 2xTx(numSteps+1) matrix containing the points of the geodesic

% Verification that the curves are of dimension 2xT
    if size(curveStart, 1) ~= 2 || size(curveEnd, 1) ~= 2
        error('Both curves must have dimensions 2xT.');
    end

    angleBetweenCurves = acos(computeCurveInnerProduct(curveStart, curveEnd));

    geodesicPath = zeros(2, size(curveStart, 2), numSteps + 1);

    if angleBetweenCurves > 1e-4
        for step = 1:numSteps + 1
            interpolationFactor = (step - 1) / numSteps;
            geodesicPoint = (sin((1 - interpolationFactor) * angleBetweenCurves) * curveStart + ...
                             sin(interpolationFactor * angleBetweenCurves) * curveEnd) / sin(angleBetweenCurves);
            geodesicPath(:, :, step) = ProjectCurveToNormalSpace(geodesicPoint);
        end
    else
        for step = 1:numSteps + 1
            geodesicPath(:, :, step) = curveStart;
        end
    end
end
