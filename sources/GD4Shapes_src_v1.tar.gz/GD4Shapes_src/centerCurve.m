function centeredCurve = centerCurve(curve)

    if size(curve, 1) ~= 2
        error('The input curve must have dimensions 2xT.');
    end
    
    centroid = mean(curve, 2);
    centroid_expanded = repmat(centroid, 1, size(curve, 2));
    centeredCurve = curve - centroid_expanded;
end
