function q_normalized = curveToUnitCurve(curve)
% curveToUnitCurve: Computes the unit representation of a 2xT curve
%
% Inputs:
% - curve: 2xT matrix representing the original curve in 2D
%
% Output:
% - q_normalized: 2xT matrix representing the normalized curve

% Checking input dimensions
    if size(curve, 1) ~= 2
        error('The input curve must have dimensions 2xT.');
    end

    deltaCurve = [diff(curve, 1, 2), curve(:, end) - curve(:, end-1)];

    magnitude = sqrt(sum(deltaCurve .^ 2, 1));
    q = deltaCurve ./ max(magnitude, 1e-10);

    normalizationFactor = sqrt(computeCurveInnerProduct(q, q));
    q_normalized = q / normalizationFactor;
end
