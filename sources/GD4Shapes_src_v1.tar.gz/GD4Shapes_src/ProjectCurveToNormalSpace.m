function projectedCurve = ProjectCurveToNormalSpace(curve)
% ProjectCurveToNormalSpace: Projects a curve to normal space
%
% Inputs:
% - curve: 2xT matrix representing the curve to be projected
%
% Output:
% - projectedCurve: Curve projected to normal space

% Validation of the dimensions of the curve
    [numDimensions, numPoints] = size(curve);
    if numDimensions ~= 2
        error('The curve must have dimensions 2xT.');
    end
    

    dt = 0.35;
    tolerance = 1e-6;
    maxIterations = 300;
    
    iteration = 1;
    residual = ones(1, numDimensions);
    jacobian = zeros(numDimensions, numDimensions);
    normalizedParam = linspace(0, 1, numPoints);

    projectedCurve = curve / sqrt(computeCurveInnerProduct(curve, curve));
    
    while norm(residual) > tolerance
        if iteration > maxIterations
            disp('Maximum number of iterations reached.');
            break;
        end

        for i = 1:numDimensions
            for j = 1:numDimensions
                jacobian(i, j) = 3 * trapz(normalizedParam, projectedCurve(i, :) .* projectedCurve(j, :));
            end
        end
        jacobian = jacobian + eye(size(jacobian));

        curveNorms = vecnorm(projectedCurve);

        for i = 1:numDimensions
            residueValues(i) = trapz(normalizedParam, projectedCurve(i, :) .* curveNorms);
        end
        residual = -residueValues;

        if norm(residual) < tolerance
            break;
        end

        correction = jacobian \ residual';
        
        correctionSum = zeros(size(projectedCurve));
        for dimIndex = 1:numDimensions
            extendedIdentity = repmat(eye(numDimensions, 1), 1, numPoints);  
            term1 = repmat(projectedCurve(dimIndex, :) ./ curveNorms, numDimensions, 1) .* projectedCurve;
            term2 = repmat(curveNorms, numDimensions, 1) .* extendedIdentity;
            normalBasisVector = term1 + term2;

            correctionSum = correctionSum + correction(dimIndex) * normalBasisVector * dt;
        end

        projectedCurve = projectedCurve + correctionSum;
        iteration = iteration + 1;
    end

    projectedCurve = projectedCurve / sqrt(computeCurveInnerProduct(projectedCurve, projectedCurve));
end
