# Instructions for running this code:

1. Uncompress **GD4Shapes_src_v1.tar.gz** file 
2. Copy all MATLAB source files into **target directory**
3. Uncompress **samples.tar.gz** into **target directory/samples/**
3. Compile **alignment.cpp**
4. Run the MATLAB script: **script_test**

## How to compile:

In MATLAB console type:

```matlab
mex alignment.cpp
```

## How to run:

```matlab
script_test
```
