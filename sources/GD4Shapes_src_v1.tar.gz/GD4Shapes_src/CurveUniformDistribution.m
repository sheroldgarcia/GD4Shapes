function resampledCurve = CurveUniformDistribution(originalCurve, numPoints)
% Curve_Uniform_Distribution: Resamples a 2xN curve to distribute points evenly
%
% Inputs:
% - originalCurve: 2xN matrix representing the original curve in 2D
% - numPoints: Desired number of equidistant points on the resampled curve
%
% Output:
% - resampledCurve: 2x(numPoints) matrix with points evenly distributed

% Validation that the curve is 2xN
    if size(originalCurve, 1) ~= 2
        error('The input curve must have dimensions 2xN');
    end

    segmentLengths = vecnorm(diff(originalCurve, 1, 2)); 
    cumulativeDist = [0, cumsum(segmentLengths)] / sum(segmentLengths); 
    
    [cumulativeDist, uniqueIdx] = unique(cumulativeDist);
    originalCurve = originalCurve(:, uniqueIdx);

    targetPositions = linspace(1/numPoints, 1, numPoints);

    resampledCurve = spline(cumulativeDist, originalCurve, targetPositions);
end

