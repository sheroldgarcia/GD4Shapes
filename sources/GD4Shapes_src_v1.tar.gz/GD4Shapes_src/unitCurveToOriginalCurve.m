function reconstructedCurve = unitCurveToOriginalCurve(qRepresentation)
    % unitCurveToOriginalCurve: Converts a Q representation to an original curve in the 2D plane

    [numDimensions, numPoints] = size(qRepresentation);
    if numDimensions ~= 2
        error('The input must be a 2xT matrix.');
    end

    pointNorms = vecnorm(qRepresentation);

    reconstructedCurve = zeros(numDimensions, numPoints);


    for dim = 1:2
        reconstructedCurve(dim, :) = cumtrapz(qRepresentation(dim, :) .* pointNorms) / numPoints;
    end
end
