function plot2DGeod(curveSet)
 
    colorSpec = ['m', 'k', 'g', 'c'];
    
    [dim, numPoints, numCurves] = size(curveSet);
    if dim ~= 2
        error('Curves must have dimensions 2xT.');
    end
    
    figure();
    hold on;
    
    for idx = 1:numCurves
        currentCurve = unitCurveToOriginalCurve(curveSet(:,:,idx)); 
        
        if idx == 1
            plot(currentCurve(1,:), currentCurve(2,:), 'Color', 'b', 'LineWidth', 2); 
        elseif idx < numCurves
            plot(currentCurve(1,:), currentCurve(2,:), 'Color', colorSpec(mod(idx-1, length(colorSpec))+1), 'LineWidth', 1); 
        else
            plot(currentCurve(1,:), currentCurve(2,:), 'Color', 'r', 'LineWidth', 2);
        end
    end
    

    ax = gca;
    ax.FontSize = 16;   
    ax.LineWidth = 2;   
    ax.Box = 'off';     
    
    hold off;
end
