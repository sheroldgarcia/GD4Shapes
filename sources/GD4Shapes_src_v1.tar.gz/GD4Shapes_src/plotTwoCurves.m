function plotTwoCurves(curve1, curve2, plotTitle)
    % plotTwoCurves: Plot two curves in 2D

    if size(curve1, 1) ~= 2 || size(curve2, 1) ~= 2
        error('Both curves must have dimensions 2xT.');
    end
    
    figure();
    hold on;
    plot(curve1(1, :), curve1(2, :), 'b', 'LineWidth', 2);  
    plot(curve2(1, :), curve2(2, :), 'r', 'LineWidth', 2);  
    

    plot(curve1(1, 1), curve1(2, 1), 'bo', 'MarkerFaceColor', 'b'); 
    plot(curve2(1, 1), curve2(2, 1), 'ro', 'MarkerFaceColor', 'r'); 
    

    title(plotTitle);
    axis equal;
    hold off;
end
