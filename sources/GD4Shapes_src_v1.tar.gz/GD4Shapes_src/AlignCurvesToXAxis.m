function [aligned_curve1, aligned_curve2, rotation_matrix1, rotation_matrix2] = AlignCurvesToXAxis(curve1, curve2)
% AlignCurvesToXAxisIndependently: Aligns two curves centered at the origin by
% rearranging them to start from the point farthest from the centroid, then rotates each curve
% so that its major axis is aligned with the X axis, and finally rearranges both curves to
% start at the point that coincides with the positive X axis.
%
% Inputs:
% - curve1: First curve centered at origin (2xT matrix)
% - curve2: Second curve centered at origin (2xT matrix)
%
% Outputs:
% - aligned_curve1: curve1 aligned to X axis
% - aligned_curve2: curve2 aligned to X axis
% - rotation_matrix1: Rotation matrix applied to curve1
% - rotation_matrix2: Rotation matrix applied to curve2

% Error checking
    if ~ismatrix(curve1) || ~ismatrix(curve2)
        error('Inputs must be numeric arrays.');
    end
    if size(curve1, 1) ~= 2 || size(curve2, 1) ~= 2
        error('Both curves must have exactly two rows (X and Y coordinates).');
    end
    if size(curve1, 2) ~= size(curve2, 2)
        error('Curves must have the same number of columns (T points).');
    end
    if any(mean(curve1, 2) > 1e-10) || any(mean(curve2, 2) > 1e-10)
        error('The curves must be centered at the origin (centroid at [0; 0]).');
    end

% Step 1: Rearrange each curve to start from the point furthest from the centroid

    distances1 = sqrt(sum((curve1 - mean(curve1, 2)).^2, 1));
    [~, max_idx1] = max(distances1);
    curve1 = [curve1(:, max_idx1:end), curve1(:, 1:max_idx1-1)];
    

    distances2 = sqrt(sum((curve2 - mean(curve2, 2)).^2, 1));
    [~, max_idx2] = max(distances2);
    curve2 = [curve2(:, max_idx2:end), curve2(:, 1:max_idx2-1)];

% Step 2: Compute the rotation needed for each curve to align with the X axis

    angle_to_x_axis1 = atan2(curve1(2,1), curve1(1,1));
    rotation_matrix1 = [cos(-angle_to_x_axis1), -sin(-angle_to_x_axis1); 
                        sin(-angle_to_x_axis1), cos(-angle_to_x_axis1)];
    aligned_curve1 = rotation_matrix1 * curve1;
    

    angle_to_x_axis2 = atan2(curve2(2,1), curve2(1,1));
    rotation_matrix2 = [cos(-angle_to_x_axis2), -sin(-angle_to_x_axis2); 
                        sin(-angle_to_x_axis2), cos(-angle_to_x_axis2)];
    aligned_curve2 = rotation_matrix2 * curve2;
    
% Step 3: Rearrange each curve so that it starts from the most positive point on the X axis
    [~, start_idx1] = max(aligned_curve1(1, :));
    aligned_curve1 = [aligned_curve1(:, start_idx1:end), aligned_curve1(:, 1:start_idx1-1)];
    
    [~, start_idx2] = max(aligned_curve2(1, :)); 
    aligned_curve2 = [aligned_curve2(:, start_idx2:end), aligned_curve2(:, 1:start_idx2-1)];
end
