#include "mex.h"
#include <cmath>
#include <vector>
#include <algorithm>
#include <cstdlib>
#include <stdexcept>

#define NUM_NEIGHBORS 23

const int neighbors[NUM_NEIGHBORS][2] = { 
    {1, 1}, {1, 2}, {2, 1}, {2, 3}, {3, 2}, {1, 3}, {3, 1},
    {1, 4}, {3, 4}, {4, 3}, {4, 1}, {1, 5}, {2, 5}, {3, 5},
    {4, 5}, {5, 4}, {5, 3}, {5, 2}, {5, 1}, {1, 6}, {5, 6},
    {6, 5}, {6, 1}
};

double ComputeCost(const double *sourceData, const double *targetData, const std::vector<double> &interpolatedTarget, 
                  int prevRow, int prevCol, int currentRow, int currentCol, 
                  int numFeatures, int totalRows, int totalInterpolations) {

    double slope = static_cast<double>(currentCol - prevCol) / (currentRow - prevRow);
    double sqrtSlope = std::sqrt(slope);
    double totalEnergy = 0.0;
    
    double interpolatedY, fractionalPart, integerPart;
    int currentX, interpolationIndex, featureIdx;
    
    for (currentX = prevRow; currentX <= currentRow; ++currentX) {
        interpolatedY = (currentX - prevRow) * slope + prevCol + 1.0;
        fractionalPart = std::modf(interpolatedY * totalInterpolations / totalRows, &integerPart);
        interpolationIndex = static_cast<int>(integerPart + (fractionalPart >= 0.5)) - 1;

        interpolationIndex = std::max(0, std::min(interpolationIndex, totalInterpolations - 2));

        int base_source = numFeatures * currentX;
        int base_interpolated = numFeatures * interpolationIndex;

        for (featureIdx = 0; featureIdx < numFeatures; ++featureIdx) {
            double difference = sourceData[base_source + featureIdx] - 
                                sqrtSlope * interpolatedTarget[base_interpolated + featureIdx];
            totalEnergy += difference * difference;
        }
    }

    return totalEnergy / static_cast<double>(totalRows);
}


void ComputeCubicSpline(std::vector<double> &splineCoefficients, const double *dataPoints, int numPoints) {

    static std::vector<double> lowerDiagonal_static;
    static std::vector<double> mainDiagonal_static;
    static std::vector<double> upperDiagonal_static;


    if (lowerDiagonal_static.size() != static_cast<size_t>(numPoints)) {
        lowerDiagonal_static.assign(numPoints, 0.0);
        mainDiagonal_static.assign(numPoints, 0.0);
        upperDiagonal_static.assign(numPoints, 0.0);
    }


    std::vector<double> &lowerDiagonal = lowerDiagonal_static;
    std::vector<double> &mainDiagonal = mainDiagonal_static;
    std::vector<double> &upperDiagonal = upperDiagonal_static;


    if (numPoints < 4) {

        lowerDiagonal[0] = 0.0; 
        mainDiagonal[0] = 2.0; 
        upperDiagonal[0] = 1.0; 
        splineCoefficients[0] = 3.0 * (dataPoints[1] - dataPoints[0]);
        
        lowerDiagonal[numPoints - 1] = 1.0; 
        mainDiagonal[numPoints - 1] = 2.0; 
        upperDiagonal[numPoints - 1] = 0.0; 
        splineCoefficients[numPoints - 1] = 3.0 * (dataPoints[numPoints - 1] - dataPoints[numPoints - 2]);
    } else {

        lowerDiagonal[0] = 0.0; 
        mainDiagonal[0] = 2.0; 
        upperDiagonal[0] = 4.0; 
        splineCoefficients[0] = -5.0 * dataPoints[0] + 4.0 * dataPoints[1] + dataPoints[2];
        
        lowerDiagonal[numPoints - 1] = 4.0; 
        mainDiagonal[numPoints - 1] = 2.0; 
        upperDiagonal[numPoints - 1] = 0.0; 
        splineCoefficients[numPoints - 1] = 5.0 * dataPoints[numPoints - 1] - 4.0 * dataPoints[numPoints - 2] - dataPoints[numPoints - 3];
    }


    if (numPoints > 2) {

        std::fill(lowerDiagonal.begin() + 1, lowerDiagonal.begin() + numPoints - 1, 1.0);
        std::fill(upperDiagonal.begin() + 1, upperDiagonal.begin() + numPoints - 1, 1.0);

        std::fill(mainDiagonal.begin() + 1, mainDiagonal.begin() + numPoints - 1, 4.0);
    }


    for (int i = 1; i < numPoints - 1; ++i) {
        splineCoefficients[i] = 3.0 * (dataPoints[i + 1] - dataPoints[i - 1]);
    }

    // Algoritmo de Thomas 
    upperDiagonal[0] /= mainDiagonal[0];
    splineCoefficients[0] /= mainDiagonal[0];

    for (int i = 1; i < numPoints; ++i) {
        double denominator = mainDiagonal[i] - lowerDiagonal[i] * upperDiagonal[i - 1];
        if (denominator == 0.0) {
            throw std::runtime_error("Denominator in Thomas algorithm is zero.");
        }
        upperDiagonal[i] /= denominator;
        splineCoefficients[i] = (splineCoefficients[i] - lowerDiagonal[i] * splineCoefficients[i - 1]) / denominator;
    }

    for (int i = numPoints - 2; i >= 0; --i) {
        splineCoefficients[i] -= upperDiagonal[i] * splineCoefficients[i + 1];
    }
}

void EvaluateSplineParameter(double &fraction, int &segmentIndex, double currentDistance, double totalLength, int numPoints) {
    double numPointsMinus1 = static_cast<double>(numPoints - 1);
    
    fraction = numPointsMinus1 * currentDistance / totalLength;
    
    segmentIndex = static_cast<int>(std::floor(fraction));
    
    int numPointsMinus2 = numPoints - 2;
    
    segmentIndex = (segmentIndex < 0) ? 0 : ((segmentIndex > numPointsMinus2) ? numPointsMinus2 : segmentIndex);
    
    fraction -= static_cast<double>(segmentIndex);
}


inline double CubicSplineInterpolate(double parameter, const double derivatives[2], const double values[2]) {
    double coefficients[4];
    coefficients[0] = values[0];
    coefficients[1] = derivatives[0];
    coefficients[2] = 3.0 * (values[1] - values[0]) - 2.0 * derivatives[0] - derivatives[1];
    coefficients[3] = 2.0 * (values[0] - values[1]) + derivatives[0] + derivatives[1];
    return ((coefficients[3] * parameter + coefficients[2]) * parameter + coefficients[1]) * parameter + coefficients[0];
}


void mexFunction(int nlhs, mxArray *plhs[], int nrhs, const mxArray *prhs[]) {

    if (nrhs != 2)
        mexErrMsgTxt("Usage: [output] = alignment(q1, q2)");


    if (!mxIsDouble(prhs[0]) || !mxIsDouble(prhs[1]))
        mexErrMsgTxt("Expected double precision arguments.");


    int numFeatures = mxGetM(prhs[0]);
    int numPoints = mxGetN(prhs[0]);
    if (numFeatures != mxGetM(prhs[1]) || numPoints != mxGetN(prhs[1]))
        mexErrMsgTxt("Dimension mismatch between first and second argument.");

    plhs[0] = mxCreateDoubleMatrix(1, numPoints, mxREAL);
    double *output = mxGetPr(plhs[0]);
    const double *sourceData = mxGetPr(prhs[0]);
    const double *targetData = mxGetPr(prhs[1]);


    int numInterpolations = 5 * numPoints;

    std::vector<double> interpolatedTarget;
    interpolatedTarget.reserve(numFeatures * numInterpolations);
    interpolatedTarget.assign(numFeatures * numInterpolations, 0.0);

    std::vector<double> splineCoefficients;
    splineCoefficients.reserve(2 * numPoints);
    splineCoefficients.assign(2 * numPoints, 0.0); 

    std::vector<double> tempValues;
    tempValues.reserve(numPoints);
    tempValues.assign(numPoints, 0.0);

    double scalingFactor = 1.0 / numPoints;
    double offset = 1.0;

    for (int featureIdx = 0; featureIdx < numFeatures; ++featureIdx) {

        for (int pointIdx = 0; pointIdx < numPoints; ++pointIdx)
            tempValues[pointIdx] = targetData[numFeatures * pointIdx + featureIdx];
        

        ComputeCubicSpline(splineCoefficients, tempValues.data(), numPoints);
        

        for (int interpIdx = 0; interpIdx < numInterpolations; ++interpIdx) {
            double parameter;
            int segmentIndex;
            double currentDistance = (interpIdx + 1.0) / numInterpolations - scalingFactor;
            double totalLength = offset - scalingFactor;
            EvaluateSplineParameter(parameter, segmentIndex, currentDistance, totalLength, numPoints);
            

            interpolatedTarget[numFeatures * interpIdx + featureIdx] = CubicSplineInterpolate(parameter, &splineCoefficients[segmentIndex], &tempValues[segmentIndex]);
        }
    }


    std::vector<double> costMatrix(numPoints * numPoints, 1e5);
    std::vector<int> pathMatrix(2 * numPoints * numPoints, -1);

    std::fill(costMatrix.begin(), costMatrix.end(), 1e5);

    for (int pointIdx = 0; pointIdx < numPoints; ++pointIdx) {
        costMatrix[numPoints * pointIdx + 0] = 1.0;       // Column 0
        costMatrix[numPoints * 0 + pointIdx] = 1.0;       // Row 0
    }
    costMatrix[numPoints * 0 + 0] = 0.0;

    for (int colIdx = 1; colIdx < numPoints; ++colIdx) {

        int base_pathRow = numPoints * (numPoints * 0 + colIdx); // pathMatrixRow
        int base_pathCol = numPoints * (numPoints * 1 + colIdx); // pathMatrixCol

        for (int rowIdx = 1; rowIdx < numPoints; ++rowIdx) {
            double minCost = 1e5;
            int minNeighborIdx = 0;

            for (int neighborIdx = 0; neighborIdx < NUM_NEIGHBORS; ++neighborIdx) {
                int prevRow = rowIdx - neighbors[neighborIdx][0];
                int prevCol = colIdx - neighbors[neighborIdx][1];
                if (prevRow >= 0 && prevCol >= 0) {
                    double currentCost = costMatrix[numPoints * prevCol + prevRow] + 
                        ComputeCost(sourceData, targetData, interpolatedTarget, prevRow, prevCol, rowIdx, colIdx, numFeatures, numPoints, numInterpolations);
                    if (currentCost < minCost) {
                        minCost = currentCost;
                        minNeighborIdx = neighborIdx;
                    }
                }
            }
            costMatrix[numPoints * colIdx + rowIdx] = minCost;

            pathMatrix[base_pathRow + rowIdx] = rowIdx - neighbors[minNeighborIdx][0];
            pathMatrix[base_pathCol + rowIdx] = colIdx - neighbors[minNeighborIdx][1];
        }
    }


    std::vector<int> pathX(2 * numPoints, 0), pathY(2 * numPoints, 0);
    pathX[0] = pathY[0] = numPoints - 1;

    int pathCount = 1;
    while (pathX[pathCount - 1] > 0) {
        pathY[pathCount] = pathMatrix[numPoints * (numPoints * 0 + pathX[pathCount - 1]) + pathY[pathCount - 1]];
        pathX[pathCount] = pathMatrix[numPoints * (numPoints * 1 + pathX[pathCount - 1]) + pathY[pathCount - 1]];
        if (pathCount >= 2 * numPoints - 1) break; 
        ++pathCount;
    }

    std::reverse(pathX.begin(), pathX.begin() + pathCount);
    std::reverse(pathY.begin(), pathY.begin() + pathCount);

    bool isPathXSorted = true;
    for (int i = 1; i < pathCount; ++i) {
        if (pathX[i] < pathX[i - 1]) {
            isPathXSorted = false;
            break;
        }
    }

    if (!isPathXSorted) {
        mexErrMsgTxt("pathX is not sorted.");
    }

    for (int pointIdx = 0; pointIdx < numPoints; ++pointIdx) {
        auto it = std::lower_bound(pathX.begin(), pathX.begin() + pathCount, pointIdx);
        int closestIndex = 0;

        if (it == pathX.begin()) {
            closestIndex = 0;
        }
        else if (it == pathX.begin() + pathCount) {
            closestIndex = pathCount - 1;
        }
        else {
            int idx = std::distance(pathX.begin(), it);
            double dist1 = std::abs(pathX[idx] - pointIdx);
            double dist2 = std::abs(pathX[idx - 1] - pointIdx);
            closestIndex = (dist1 < dist2) ? idx : (idx - 1);
        }

        if (pathX[closestIndex] == pointIdx) {
            output[pointIdx] = pathY[closestIndex] + 1;
        }
        else {
            if (pathX[closestIndex] > pointIdx) {
                double alpha = static_cast<double>(pathX[closestIndex] - pointIdx);
                double beta = static_cast<double>(pointIdx - pathX[closestIndex - 1]);
                output[pointIdx] = (alpha * (pathY[closestIndex - 1] + 1) + beta * (pathY[closestIndex] + 1)) / (alpha + beta);
            }
            else {
                double alpha = static_cast<double>(pointIdx - pathX[closestIndex]);
                double beta = static_cast<double>(pathX[closestIndex + 1] - pointIdx);
                output[pointIdx] = (alpha * (pathY[closestIndex + 1] + 1) + beta * (pathY[closestIndex] + 1)) / (alpha + beta);
            }
        }

        output[pointIdx] /= static_cast<double>(numPoints);
    }
}
